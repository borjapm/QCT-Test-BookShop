﻿namespace Bookstore.Common
{
    public static class Constants
    {
        public static readonly string AppName = "BobsUsedBooksClassic";
    }
}